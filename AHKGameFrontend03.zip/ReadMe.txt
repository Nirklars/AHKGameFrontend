AHK Game Frontend Launcher Version 0.3
Written by Nicklas

https://nirklars.wordpress.com/ahkgamefrontend/

Compiled using AutoHotkey 1.0.48.05
http://www.autohotkey.com/board/topic/86134-autohotkey-10-classic-and-basic-versions/
Edit compile.bat to point to your AutoHotkey install directory

Best Regards
Nick